@echo off
rem Starts Job Tracker on this computer. Keep this window open while you use it.
title Job Tracker
cd /d "%~dp0"
"%~dp0runtime\node.exe" "%~dp0launcher\start.mjs"
echo.
pause
