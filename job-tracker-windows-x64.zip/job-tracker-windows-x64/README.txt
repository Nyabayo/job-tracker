Job Tracker, local version (no Docker needed)
==============================================

Start:  double-click start.cmd
Open:   http://localhost:3000 (it opens by itself once ready)
Stop:   press Ctrl+C in the Job Tracker window, or close it

The first start takes a little longer while the database is created.

What runs where
- Everything stays on this computer. The app and its database only listen
  on 127.0.0.1, so other computers on your network can't reach them.
- Your data lives in the "data" folder next to start.cmd: the database,
  uploaded files and the random keys made on first start (secrets.json).
  Keep that folder private and back it up if your data matters.
- Emails (sign-up confirmation, password reset) are not sent. They are
  printed in the Job Tracker window: copy the link from there into your
  browser.
- Uploaded files are checked by type and size, but not scanned for viruses
  (that needs ClamAV, which the Docker version includes).

Ports: the app uses 3000 and the database 54329. If 3000 is taken, open a
command prompt in this folder and run:  set PORT=3001 && start.cmd
