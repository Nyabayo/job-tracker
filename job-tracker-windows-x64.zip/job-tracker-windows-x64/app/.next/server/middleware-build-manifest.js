globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/UGZtZYJl318m10H7935Ug/_buildManifest.js",
    "static/UGZtZYJl318m10H7935Ug/_ssgManifest.js",
    "static/UGZtZYJl318m10H7935Ug/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1x6obpmlu1_c2.js",
    "static/chunks/0wg72f7f3emb8.js",
    "static/chunks/1kslmajajhm06.js",
    "static/chunks/3ik3czu5vv_41.js",
    "static/chunks/1mtjo5did8k54.js",
    "static/chunks/turbopack-2c3mg3r-05n1w.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/archive/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/board/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/dashboard/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/jobs/[id]/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/jobs/new/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/more/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/notifications/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/settings/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(app)/tasks/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/check-email/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/forgot-password/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/login/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/login/two-factor/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/reset-password/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/signup/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/verify-email/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/goodbye/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/privacy/page": {
      "otherChunks": [
        "static/chunks/1x6obpmlu1_c2.js",
        "static/chunks/0wg72f7f3emb8.js",
        "static/chunks/1kslmajajhm06.js",
        "static/chunks/3ik3czu5vv_41.js",
        "static/chunks/1mtjo5did8k54.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
