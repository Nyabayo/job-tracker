var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__1fg36kwyg90i_._.js")
R.c("server/chunks/[root-of-the-server]__0t9ufnv5hi2hq._.js")
R.m(62395)
module.exports=R.m(62395).exports
