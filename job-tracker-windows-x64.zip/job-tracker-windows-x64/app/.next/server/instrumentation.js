var R=require("./chunks/[turbopack]_runtime.js")("server/instrumentation.js")
R.c("server/chunks/_1z8tcmtujrzu1._.js")
R.m(69449)
module.exports=R.m(69449).exports
