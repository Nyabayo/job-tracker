(()=>{"use strict";module.exports=[23862,r=>r.a(async(e,a)=>{try{var t=await r.y("pg-587764f78a6c7a9c");r.n(t),a()}catch(r){a(r)}},!0),93395,r=>r.a(async(e,a)=>{try{var t=r.i(23862),s=e([t]);async function n(r,e){let a=new t.Client({connectionString:r});await a.connect();try{let{rows:r}=await a.query(`
      SELECT r.rolsuper, r.rolbypassrls,
             EXISTS (SELECT 1 FROM pg_tables WHERE tablename = 'users' AND tableowner = current_user) AS owns_users
      FROM pg_roles r WHERE r.rolname = current_user`),t=r[0];if(!t)throw Error(`${e}: could not read the current database role`);if(t.rolsuper||t.rolbypassrls||t.owns_users)throw Error(`${e} connects as a role that can bypass row-level security. Use the jt_app / jt_auth roles, never the owner or a superuser.`)}finally{await a.end()}}[t]=s.then?(await s)():s,r.s(["assertSafeDatabaseRole",0,n]),a()}catch(r){a(r)}},!1)]})();

//# sourceMappingURL=%5Broot-of-the-server%5D__1o6mgq6q_nl9c._.js.map