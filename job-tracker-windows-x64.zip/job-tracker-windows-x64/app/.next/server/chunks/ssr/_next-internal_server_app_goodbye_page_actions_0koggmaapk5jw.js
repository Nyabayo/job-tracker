module.exports=[84240,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_goodbye_page_actions_0koggmaapk5jw.js.map