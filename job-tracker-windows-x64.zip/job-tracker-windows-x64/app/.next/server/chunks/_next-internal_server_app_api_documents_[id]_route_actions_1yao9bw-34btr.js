module.exports=[34771,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_documents_%5Bid%5D_route_actions_1yao9bw-34btr.js.map