var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/documents/[id]/route.js")
R.c("server/chunks/[externals]__03xr5xb-l_-3f._.js")
R.c("server/chunks/lib_1rvbv26d21gjd._.js")
R.c("server/chunks/[root-of-the-server]__12avrqbq0zsvl._.js")
R.c("server/chunks/_0uqvoa17uv85k._.js")
R.c("server/chunks/_1i0l9c834_53u._.js")
R.c("server/chunks/_next-internal_server_app_api_documents_[id]_route_actions_1yao9bw-34btr.js")
R.m(25315)
module.exports=R.m(25315).exports
