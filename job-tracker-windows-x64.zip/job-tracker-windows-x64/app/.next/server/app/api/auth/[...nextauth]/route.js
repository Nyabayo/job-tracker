var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[externals]__20vf0zaokhn9u._.js")
R.c("server/chunks/_0xrnuwmugxlnp._.js")
R.c("server/chunks/[root-of-the-server]__1aaw59g-5uty7._.js")
R.c("server/chunks/_17ssriee-sk2b._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_[___nextauth]_route_actions_08nexdks3z54l.js")
R.m(59061)
module.exports=R.m(59061).exports
