var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/health/route.js")
R.c("server/chunks/[externals]__06hhnul6t2rkt._.js")
R.c("server/chunks/[root-of-the-server]__1aaw59g-5uty7._.js")
R.c("server/chunks/_0061c2q1_b2kh._.js")
R.c("server/chunks/_next-internal_server_app_api_health_route_actions_1ryftkbeskq31.js")
R.m(61370)
module.exports=R.m(61370).exports
