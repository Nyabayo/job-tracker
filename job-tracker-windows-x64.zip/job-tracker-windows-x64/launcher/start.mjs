// Starts Job Tracker on this computer without Docker.
//
// The database is a private Postgres 16 server that runs from this folder and
// only listens on 127.0.0.1, with the same three roles and row-level security
// as the Docker setup. Uploaded files go to data/files, emails are printed in
// this window, and virus scanning is off (file type and size checks still run).
//
// Layout (made by scripts/local/build-package.mjs):
//   launcher/start.mjs   this file, with pg and the Postgres binaries
//   launcher/sql/        roles.sql, rls.sql and the migrations
//   app/                 the built app (Next.js standalone server)
//   data/                created on first start: database, files, secrets
import { spawn, spawnSync } from "node:child_process";
import { createHash, randomBytes, randomUUID } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from "node:fs";
import path from "node:path";
import process from "node:process";
import pg from "pg";

/* eslint-disable security/detect-non-literal-fs-filename -- every path is built from this folder's fixed layout */

const LAUNCHER = import.meta.dirname;
const ROOT = path.resolve(LAUNCHER, "..");
const APP = path.join(ROOT, "app");
const SQL = path.join(LAUNCHER, "sql");
const DATA = path.join(ROOT, "data");
const PGDATA = path.join(DATA, "pgdata");
const FILES = path.join(DATA, "files");
const SECRETS = path.join(DATA, "secrets.json");
const PORT = Number(process.env.PORT ?? 3000);
const DB_PORT = Number(process.env.JT_DB_PORT ?? 54329);
const DB_NAME = "jobtracker";
const APP_URL = `http://localhost:${PORT}`;

const say = (msg) => console.log(`[job-tracker] ${msg}`);

function fail(msg) {
  console.error(`\n[job-tracker] ${msg}\n`);
  process.exit(1);
}

// ---- secrets: random on first start, kept in data/secrets.json ------------
function loadSecrets() {
  if (existsSync(SECRETS)) return JSON.parse(readFileSync(SECRETS, "utf8"));
  const hex = (n) => randomBytes(n).toString("hex");
  const secrets = {
    superuser: hex(24),
    owner: hex(24),
    app: hex(24),
    auth: hex(24),
    authSecret: hex(32),
    totpKey: hex(32),
  };
  writeFileSync(SECRETS, JSON.stringify(secrets, null, 2), { mode: 0o600 });
  return secrets;
}

// ---- Postgres ---------------------------------------------------------------
async function pgBinaries() {
  const name = process.platform === "win32" ? "windows-x64" : `${process.platform}-${process.arch}`;
  try {
    return await import(`@embedded-postgres/${name}`);
  } catch {
    fail(`This package has no database for ${process.platform} ${process.arch}.`);
  }
}

// pipe: false for `pg_ctl start`, whose server would otherwise hold the pipes
// open on Windows and keep this call from returning.
function run(bin, args, pipe = true) {
  const r = spawnSync(bin, args, { stdio: pipe ? ["ignore", "pipe", "pipe"] : "ignore", encoding: "utf8" });
  return { ok: r.status === 0, out: `${r.stdout ?? ""}${r.stderr ?? ""}`.trim() };
}

async function startDatabase(bin, secrets) {
  if (!existsSync(path.join(PGDATA, "PG_VERSION"))) {
    say("Creating the database (first start only)...");
    rmSync(PGDATA, { recursive: true, force: true });
    const pwfile = path.join(DATA, `pw-${randomBytes(6).toString("hex")}`);
    writeFileSync(pwfile, `${secrets.superuser}\n`, { mode: 0o600 });
    try {
      const r = run(bin.initdb, [
        `--pgdata=${PGDATA}`, "--username=postgres", `--pwfile=${pwfile}`,
        "--auth=scram-sha-256", "--encoding=UTF8", "--locale=C",
      ]);
      if (!r.ok) fail(`The database could not be created:\n${r.out}`);
    } finally {
      rmSync(pwfile, { force: true });
    }
  }
  if (run(bin.pg_ctl, ["status", "-D", PGDATA]).ok) {
    say("The database is already running.");
    return;
  }
  say("Starting the database...");
  const r = run(bin.pg_ctl, [
    "start", "-D", PGDATA, "-w", "-t", "120", "-l", path.join(DATA, "postgres.log"),
    "-o", `-p ${DB_PORT} -c listen_addresses=127.0.0.1`,
  ], false);
  if (!r.ok) {
    const log = path.join(DATA, "postgres.log");
    const tail = existsSync(log) ? readFileSync(log, "utf8").split("\n").slice(-15).join("\n") : "";
    fail(`The database did not start. Details are in ${log}\n${tail}`);
  }
}

function stopDatabase(bin) {
  run(bin.pg_ctl, ["stop", "-D", PGDATA, "-m", "fast", "-w", "-t", "30"]);
}

const url = (user, password, db = DB_NAME) =>
  `postgresql://${user}:${encodeURIComponent(password)}@127.0.0.1:${DB_PORT}/${db}`;

async function withClient(connectionString, fn) {
  const client = new pg.Client({ connectionString });
  await client.connect();
  try {
    return await fn(client);
  } finally {
    await client.end();
  }
}

// roles.sql is written for psql (:'var' literals, :"var" identifiers and a
// \connect line). Fill the variables in and run each half on its database.
function fillRolesTemplate(sql, vars) {
  const value = (k) => {
    if (!Object.hasOwn(vars, k)) throw new Error(`roles.sql uses an unknown variable :${k}`);
    // eslint-disable-next-line security/detect-object-injection -- own key checked above
    return String(vars[k]);
  };
  const literal = (k) => `'${value(k).replace(/'/g, "''")}'`;
  const ident = (k) => `"${value(k).replace(/"/g, '""')}"`;
  return sql.replace(/:'(\w+)'/g, (_, k) => literal(k)).replace(/:"(\w+)"/g, (_, k) => ident(k));
}

// Splits SQL into statements at semicolons that end a line, dropping
// comment-only pieces.
function statements(sql) {
  return sql
    .split(/;[ \t]*$/m)
    .map((s) => s.trim())
    .filter((s) => s.split("\n").some((line) => line.trim() !== "" && !line.trim().startsWith("--")));
}

async function setUpRoles(secrets) {
  const superUrl = url("postgres", secrets.superuser, "postgres");
  const exists = await withClient(superUrl, async (c) => (await c.query("SELECT 1 FROM pg_roles WHERE rolname = 'jt_owner'")).rowCount > 0);
  if (exists) return;
  say("Creating the database roles...");
  const sql = fillRolesTemplate(readFileSync(path.join(SQL, "roles.sql"), "utf8"), {
    owner_password: secrets.owner, app_password: secrets.app, auth_password: secrets.auth, db_name: DB_NAME,
  });
  const [server, database] = sql.split(/^\\connect .*$/m);
  // CREATE DATABASE can't run inside a transaction, so run statements one by one.
  await withClient(superUrl, async (c) => {
    for (const stmt of statements(server)) {
      await c.query(stmt);
    }
  });
  await withClient(url("postgres", secrets.superuser), (c) => c.query(database));
}

// Same bookkeeping table as `prisma migrate deploy`, so either tool can be used later.
async function migrate(secrets) {
  await withClient(url("jt_owner", secrets.owner), async (c) => {
    await c.query(`CREATE TABLE IF NOT EXISTS "_prisma_migrations" (
      "id" VARCHAR(36) PRIMARY KEY NOT NULL, "checksum" VARCHAR(64) NOT NULL, "finished_at" TIMESTAMPTZ,
      "migration_name" VARCHAR(255) NOT NULL, "logs" TEXT, "rolled_back_at" TIMESTAMPTZ,
      "started_at" TIMESTAMPTZ NOT NULL DEFAULT now(), "applied_steps_count" INTEGER NOT NULL DEFAULT 0)`);
    const done = new Set((await c.query(`SELECT migration_name FROM "_prisma_migrations" WHERE finished_at IS NOT NULL`)).rows.map((r) => r.migration_name));
    const dir = path.join(SQL, "migrations");
    for (const name of readdirSync(dir).filter((n) => existsSync(path.join(dir, n, "migration.sql"))).sort()) {
      if (done.has(name)) continue;
      say(`Updating the database: ${name}`);
      const sql = readFileSync(path.join(dir, name, "migration.sql"), "utf8");
      await c.query("BEGIN");
      try {
        await c.query(sql);
        await c.query(
          `INSERT INTO "_prisma_migrations" (id, checksum, finished_at, migration_name, applied_steps_count) VALUES ($1, $2, now(), $3, 1)`,
          [randomUUID(), createHash("sha256").update(sql).digest("hex"), name],
        );
        await c.query("COMMIT");
      } catch (err) {
        await c.query("ROLLBACK");
        throw err;
      }
    }
    await c.query(readFileSync(path.join(SQL, "rls.sql"), "utf8"));
  });
}

// ---- the app ----------------------------------------------------------------
function startApp(secrets) {
  const env = {
    ...process.env,
    NODE_ENV: "production",
    NEXT_TELEMETRY_DISABLED: "1",
    PORT: String(PORT),
    HOSTNAME: "127.0.0.1",
    APP_URL,
    DATABASE_URL: url("jt_app", secrets.app),
    DATABASE_URL_AUTH: url("jt_auth", secrets.auth),
    AUTH_SECRET: secrets.authSecret,
    TOTP_ENCRYPTION_KEY: secrets.totpKey,
    SMTP_HOST: "console",
    EMAIL_FROM: "Job Tracker <no-reply@localhost>",
    STORAGE_DRIVER: "local",
    LOCAL_STORAGE_DIR: FILES,
    SCAN_UPLOADS: "false",
  };
  return spawn(process.execPath, [path.join(APP, "server.js")], { cwd: APP, env, stdio: "inherit" });
}

async function waitForApp(child) {
  for (let i = 0; i < 120; i++) {
    if (child.exitCode !== null) return false;
    try {
      if ((await fetch(`http://127.0.0.1:${PORT}/api/health`)).ok) return true;
    } catch {
      // not up yet
    }
    await new Promise((r) => setTimeout(r, 500));
  }
  return false;
}

function openBrowser() {
  if (process.env.JT_NO_BROWSER) return;
  const opener = process.platform === "win32" ? ["rundll32", ["url.dll,FileProtocolHandler", APP_URL]]
    : process.platform === "darwin" ? ["open", [APP_URL]] : ["xdg-open", [APP_URL]];
  spawn(opener[0], opener[1], { stdio: "ignore", detached: true }).on("error", () => {}).unref();
}

async function main() {
  if (!existsSync(path.join(APP, "server.js"))) fail("The app files are missing. Unzip the whole package and try again.");
  mkdirSync(FILES, { recursive: true, mode: 0o700 });
  const secrets = loadSecrets();
  const bin = await pgBinaries();
  await startDatabase(bin, secrets);

  let stopping = false;
  let app;
  const shutdown = (code = 0) => {
    if (stopping) return;
    stopping = true;
    say("Stopping...");
    app?.kill();
    stopDatabase(bin);
    process.exit(code);
  };
  for (const sig of ["SIGINT", "SIGTERM", "SIGHUP", "SIGBREAK"]) process.on(sig, () => shutdown(0));

  try {
    await setUpRoles(secrets);
    await migrate(secrets);
  } catch (err) {
    console.error(err);
    shutdown(1);
  }

  say("Starting Job Tracker...");
  app = startApp(secrets);
  app.on("exit", (code) => {
    if (!stopping) {
      console.error(`[job-tracker] The app stopped (code ${code}).`);
      shutdown(code ?? 1);
    }
  });
  if (await waitForApp(app)) {
    console.log(`\n  Job Tracker is running at ${APP_URL}\n  Sign-up and password emails appear in this window.\n  Keep this window open while you use the app. Press Ctrl+C to stop.\n`);
    openBrowser();
  } else if (!stopping) {
    console.error(`[job-tracker] The app didn't answer on ${APP_URL}. Is another program using port ${PORT}?`);
    shutdown(1);
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
